package com.example.myapplication.BackendClasses;

public enum ItemType {
    bbq,
    drink,
    side
}
