package com.example.myapplication;

public class Model {

    private int number;
    private String food;
    private String description;

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }

    public String getDescription(){return description;}

    public void setDescription(String description){ this.description = description;}
}